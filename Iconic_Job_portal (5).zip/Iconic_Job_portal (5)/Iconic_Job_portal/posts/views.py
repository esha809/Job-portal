from posts.models import UserProfile, Tag, Post
from django.shortcuts import render, redirect, get_object_or_404
from users.models import User
from .forms import *
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from recruiter.models import Recruiter
from company.models import Company


# --------- CREATE VIEWS --------- #

@login_required
def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            recruiter = get_object_or_404(Recruiter, user=request.user)
            post.recruiter = recruiter
            post.company = recruiter.company
            post.save()
            form.save_m2m()
            messages.success(request, "Post created successfully.")
            return redirect('list_posts')
    else:
        form = PostForm()
    return render(request, 'posts/create_post.html', {'form': form})


def create_tag(request):
    if request.method == 'POST':
        tag_name = request.POST.get('tag_name')
        tag_type = request.POST.get('tag_type')
        Tag.objects.create(tag_name=tag_name, tag_type=tag_type)
        return redirect('list_tags')
    return render(request, 'posts/create_tag.html')


def create_user(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')

        User.objects.create_user(email=email, name=name, password=password, phone=phone)
        return redirect('list_users')
    return render(request, 'posts/create_user.html')


def create_user_profile(request):
    if request.method == 'POST':
        user_id = request.POST.get('user')
        bio = request.POST.get('bio')
        profile_picture = request.FILES.get('profile_picture')
        resume = request.FILES.get('resume')
        location = request.POST.get('location')
        linkedin = request.POST.get('linkedin')
        portfolio = request.POST.get('portfolio')
        phone = request.POST.get('phone')
        github = request.POST.get('github')
        graduation_year = request.POST.get('graduation_year')

        user = User.objects.get(id=user_id)
        UserProfile.objects.create(
            user=user,
            bio=bio,
            profile_picture=profile_picture,
            resume=resume,
            location=location,
            linkedin=linkedin,
            portfolio=portfolio,
            phone=phone,
            github=github,
            graduation_year=graduation_year
        )
        return redirect('list_user_profiles')

    users = User.objects.all()
    return render(request, 'posts/create_user_profile.html', {'users': users})


# --------- LIST VIEWS --------- #

def list_posts(request):
    posts = Post.objects.all()
    return render(request, 'posts/list_posts.html', {'posts': posts})


def list_tags(request):
    tags = Tag.objects.all()
    return render(request, 'posts/list_tags.html', {'tags': tags})


def list_users(request):
    users = User.objects.all()
    return render(request, 'posts/list_users.html', {'users': users})


def list_user_profiles(request):
    user_profiles = UserProfile.objects.all()
    return render(request, 'posts/list_user_profiles.html', {'user_profiles': user_profiles})


# --------- UPDATE VIEWS --------- #

@login_required
def update_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    recruiter = get_object_or_404(Recruiter, user=request.user)

    if post.recruiter != recruiter:
        messages.error(request, "You don't have permission to update this post.")
        return redirect('list_posts')

    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            messages.success(request, "Post updated successfully.")
            return redirect('list_posts')
    else:
        form = PostForm(instance=post)

    return render(request, 'posts/update_post.html', {'form': form})


def update_tag(request, tag_id):
    tag = get_object_or_404(Tag, id=tag_id)
    if request.method == 'POST':
        tag.tag_name = request.POST.get('tag_name')
        tag.tag_type = request.POST.get('tag_type')
        tag.save()
        return redirect('list_tags')
    return render(request, 'posts/update_tag.html', {'tag': tag})


def update_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        user.name = request.POST.get('name')
        user.email = request.POST.get('email')
        user.phone = request.POST.get('phone')
        password = request.POST.get('password')
        if password:
            user.set_password(password)
        user.save()
        return redirect('list_users')
    return render(request, 'posts/update_user.html', {'user': user})


def update_user_profile(request, user_profile_id):
    user_profile = get_object_or_404(UserProfile, id=user_profile_id)
    if request.method == 'POST':
        user_id = request.POST.get('user')
        user_profile.user = User.objects.get(id=user_id)
        user_profile.bio = request.POST.get('bio')
        user_profile.profile_picture = request.FILES.get('profile_picture')
        user_profile.resume = request.FILES.get('resume')
        user_profile.location = request.POST.get('location')
        user_profile.linkedin = request.POST.get('linkedin')
        user_profile.portfolio = request.POST.get('portfolio')
        user_profile.phone = request.POST.get('phone')
        user_profile.github = request.POST.get('github')
        user_profile.graduation_year = request.POST.get('graduation_year')
        user_profile.save()
        return redirect('list_user_profiles')

    users = User.objects.all()
    return render(request, 'posts/update_user_profile.html', {'user_profile': user_profile, 'users': users})


# --------- DELETE VIEWS --------- #

@login_required
def delete_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    recruiter = get_object_or_404(Recruiter, user=request.user)

    if post.recruiter != recruiter:
        messages.error(request, "You don't have permission to delete this post.")
        return redirect('list_posts')

    post.delete()
    messages.success(request, "Post deleted successfully.")
    return redirect('list_posts')


def delete_tag(request, tag_id):
    tag = get_object_or_404(Tag, id=tag_id)
    tag.delete()
    messages.success(request, "Tag deleted successfully.")
    return redirect('list_tags')


def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    user.delete()
    messages.success(request, "User deleted successfully.")
    return redirect('list_users')


def delete_user_profile(request, user_profile_id):
    user_profile = get_object_or_404(UserProfile, id=user_profile_id)
    user_profile.delete()
    messages.success(request, "User profile deleted successfully.")
    return redirect('list_user_profiles')
